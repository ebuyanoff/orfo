window.TOPICS = {
  1: { title: 'Н и НН в суффиксах',
       ruleUrl: '/rules/topic-1.html',
       ruleHtml: '<iframe class="rule-frame" src="rules/topic-1.html" loading="lazy"></iframe>' },
  2: { title: 'Приставки ПРЕ и ПРИ',
       ruleUrl: '/rules/topic-2.html',
       ruleHtml: '<iframe class="rule-frame" src="rules/topic-2.html" loading="lazy"></iframe>' },
  3: { title: 'НЕ слитно и раздельно',
       ruleUrl: '/rules/topic-3.html',
       ruleHtml: '<iframe class="rule-frame" src="rules/topic-3.html" loading="lazy"></iframe>' },
};