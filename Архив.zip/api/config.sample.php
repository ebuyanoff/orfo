<?php
$DB_DRIVER='mysql';
$SQLITE_PATH=__DIR__.'/data.sqlite'; // fallback
$MYSQL_HOST='localhost'; $MYSQL_DB='your_database'; $MYSQL_USER='your_user'; $MYSQL_PASS='your_password'; $MYSQL_CHARSET='utf8mb4';
$CORS_ALLOW_ORIGIN='https://orfo.club';
$ADMIN_USERNAME='admin'; $ADMIN_PASSWORD='change_me_please';